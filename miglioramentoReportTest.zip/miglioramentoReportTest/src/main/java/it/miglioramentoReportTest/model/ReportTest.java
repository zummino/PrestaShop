package it.miglioramentoReportTest.model;

public class ReportTest {

	
	//Suppongo un solo caso di test per ogni test suite
		//Vedi struttura dati file excel "esiti Test"
		
		private String nomeTestSuite;
		private String nomeTest;
		private String releaseDiCreazione;
		private String locatoreUtilizzato;
		private String esitoTest;
		private String msgEsitoTest;
		private String causaRotturaTest;
		
		
		public ReportTest() {
			super();
			this.nomeTestSuite = "";
			this.nomeTest = "";
			this.releaseDiCreazione = "";
			this.locatoreUtilizzato = "";
			this.esitoTest = "Superato";
			this.msgEsitoTest = "-";
			this.causaRotturaTest = "-";
		}

		
		

		public ReportTest(String nomeTestSuite, String nomeTest, String releaseDiCreazione, String locatoreUtilizzato,
			  String esitoTest, String msgEsitoTest, String causaFallimento) {
			super();
			this.nomeTestSuite = nomeTestSuite;
			this.nomeTest = nomeTest;
			this.releaseDiCreazione = releaseDiCreazione;
			this.locatoreUtilizzato = locatoreUtilizzato;
			this.esitoTest = esitoTest;
			this.msgEsitoTest = msgEsitoTest;
			this.causaRotturaTest = causaFallimento;
		}



		

		public String getMsgEsitoTest() {
			return msgEsitoTest;
		}




		public void setMsgEsitoTest(String msgEsitoTest) {
			this.msgEsitoTest = msgEsitoTest;
		}




		public String getNomeTest() {
			return nomeTest;
		}




		public void setNomeTest(String nomeTest) {
			this.nomeTest = nomeTest;
		}




		public String getNomeTestSuite() {
			return nomeTestSuite;
		}


		public void setNomeTestSuite(String nomeTestSuite) {
			this.nomeTestSuite = nomeTestSuite;
		}


		public String getReleaseDiCreazione() {
			return releaseDiCreazione;
		}


		public void setReleaseDiCreazione(String releaseDiCreazione) {
			this.releaseDiCreazione = releaseDiCreazione;
		}


		public String getLocatoreUtilizzato() {
			return locatoreUtilizzato;
		}


		public void setLocatoreUtilizzato(String locatoreUtilizzato) {
			this.locatoreUtilizzato = locatoreUtilizzato;
		}




		public String getEsitoTest() {
			return esitoTest;
		}


		public void setEsitoTest(String esitoTest) {
			this.esitoTest = esitoTest;
		}


		public String getCausaRotturaTest() {
			return causaRotturaTest;
		}


		public void setCausaRotturaTest(String causaFallimento) {
			this.causaRotturaTest = causaFallimento;
		}
		
	
	
	
	
}
