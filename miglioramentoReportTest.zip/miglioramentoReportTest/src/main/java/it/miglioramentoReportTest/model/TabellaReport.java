package it.miglioramentoReportTest.model;

import java.util.LinkedList;

public class TabellaReport {

	
	private LinkedList<ReportTest> listaReport;

	public TabellaReport() {
		super();
		
		this.listaReport = new LinkedList<ReportTest>();
		
	}

	public TabellaReport(LinkedList<ReportTest> listaReport) {
		super();
		this.listaReport = listaReport;
	}

	public LinkedList<ReportTest> getListaReport() {
		return listaReport;
	}

	public void setListaReport(LinkedList<ReportTest> listaReport) {
		
		this.listaReport = new LinkedList<ReportTest>();
		
		for(ReportTest r: listaReport) {
			this.listaReport.add(r);
		}
		
	}
	
	
	
	public void aggiungiReport(ReportTest r) {
		
		this.listaReport.add(r);
		
	}
	
	public void visualizzaTabellaReport() {
		
		for(ReportTest r: this.listaReport) {
			System.out.println(r.getNomeTestSuite()+"	"+r.getNomeTest()+"	    "+r.getReleaseDiCreazione()+"	"+
					r.getLocatoreUtilizzato()+"	"+r.getEsitoTest()+"	"+r.getMsgEsitoTest()+"     "+r.getCausaRotturaTest());
			
		}
		
	}
	
	
	public int getNumElem() {
		int n=0;
		for(ReportTest r: this.listaReport) {
			n++;
		}
		return n;
	}
	
	
}
